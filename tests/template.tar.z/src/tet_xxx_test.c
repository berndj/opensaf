#include "tet_xxx.h"
void (*tet_startup)() = NULL, (*tet_cleanup)() = NULL;
void xxx_testcase_01(void)
{
	int result;
	result = TET_PASS;
	
	tet_printf("This test case is a example for succeed!\r\n");
	tet_result(result);
}
void xxx_testcase_02(void)
{
	int result;
	result = TET_FAIL;
	
	tet_printf("This test case is a example for failed!\r\n");
	tet_result(result);
}
struct tet_testlist tet_testlist[]={
  {xxx_testcase_01,1},
  {xxx_testcase_02,2},
  {NULL,-1,0}
};
