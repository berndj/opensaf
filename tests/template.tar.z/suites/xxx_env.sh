# Export the environment variables required for running the test.
# For example: export env_var=value

